<?php
include "connect.php";
 

if (isset($_POST['payment'])) {
    // Collect the form data
    $name = htmlspecialchars($_POST['name']);
    $card_number = htmlspecialchars($_POST['card_number']);
    $expiry_date = htmlspecialchars($_POST['expiry_date']);
    $cvv = htmlspecialchars($_POST['cvv']);

    // Simulate payment processing (replace this with your payment gateway logic)
    $payment_successful = true; // This should depend on your actual payment response

    if ($payment_successful) {

        echo "payment successfully";
        echo "<br>";
        echo "wait for enter admin details";
        ?>
        <meta http-equiv="refresh" content="2; url=http://localhost/dpy/db/adminRegister.html" />
       <?php
       exit();
       
    } else {
        // Store error message in the session
        echo "unsccessfully";
        ?>
        <meta http-equiv="refresh" content="2; url=http://localhost/dpy/db/payment.html" />
       <?php
        exit();
    }
} else {
    echo "<h2>Invalid Request</h2>";
       ?>
        <meta http-equiv="refresh" content="2; url=http://localhost/dpy/db/payment.html" />
       <?php
       exit();
}
?>
