<?php
include "connect.php";

// Check if the remove button is clicked
if (isset($_POST['remove'])) {

    // Get the values from the POST request
  
    $userEmail = $_POST['email'];
    $id = $_POST['id'];
    $product = $_POST['product'];
    $shop_name = $_POST['shop_name'];

    // SQL query to delete the item from the cart based on cart_id
    $sql = "DELETE FROM `cart` WHERE `shop_name` = '$shop_name' AND `userEmail` = '$userEmail' AND `productName` = '$product'";

    if ($conn->query($sql) === TRUE) {
        // Item removed successfully, redirect back to the cart view
        header("Location: cart_view.php?id=" . urlencode($id) . "&email=" . urlencode($userEmail));
        exit;
    } else {
        // Error occurred
        echo "Error: " . $conn->error;
    }
}

// Close the connection
$conn->close();
?>
