<?php
include "connect.php";

// Check if user is logged in (you can adjust this based on your session logic)
session_start();

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $table = "admin";

    // Execute the query
    $query = "SELECT * FROM $table where id=$id";
    $results = $conn->query($query);

    // Check if the query was successful and if there are rows returned
    if ($results && $results->num_rows > 0) {
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="displayAll.css" type="text/css">
    <link rel="stylesheet" href="logout.css" type="text/css">
    <title>Display Page</title>
    
</head>
<body>

    <!-- Logout Button -->
    <form action="logout.php" method="POST">
        <button type="submit" class="logout-btn">Logout</button>
    </form>

    <div class="totaltable">
        <h1>ADMIN DETAILS</h1>
        <table border=1 class="table">
            <div class="row">
                <tr>  
                    <!-- <th>SNO</th> -->
                    <th>FIRST NAME</th>
                    <th>LAST NAME</th>
                    <th>EMAIL</th>
                    <th>GENDER</th>
                    <th>MOBILE</th>
                    <th>ADDRESS</th> 
                    <th colspan=2>OPERATION</th>
                </tr><br><br>

                <?php
                if ($row = $results->fetch_assoc()) {
                ?>
                    <tr>
                        <td><?php echo $row['firstname']; ?></td>
                        <td><?php echo $row['lastname']; ?></td>
                        <td><?php echo $row['email']; ?></td>
                        <td><?php echo $row['gender']; ?></td>
                        <td><?php echo $row['mobile']; ?></td>
                        <td><?php echo $row['address']; ?></td>
                        <td class="edit">
                            <a href="update.php?id=<?php echo urlencode($row['id']); ?>&table=<?php echo urlencode($table); ?>" class="edit-link" style="text-decoration:none;">Edit</a>
                        </td>
                        <td class="delete">
                            <a href="delete.php?id=<?php echo urlencode($row['id']); ?>&table=<?php echo urlencode($table); ?>&email=<?php echo urlencode($row['email']); ?>" class="delete-link" style="text-decoration:none;">Del</a>
                        </td>
                    </tr>
                    <br>
                <?php
                } // loop end
                ?>

            </table>

            <div class="product">
                <div class="viewItems">
                <a href="displayProduct.php?id=<?php echo urlencode($id); ?>&email=<?php echo urlencode($row['email']); ?>">Update Products</a>
        
                </div>
                <div class="pickStatus">
                <a href="pickStatus.php?id=<?php echo urlencode($id); ?>&email=<?php echo urlencode($row['email']); ?>">Pick Status</a>
        
                </div>
            </div>
            

        </div>
    </body>
</html>

<?php
    } else {
        echo "ERROR " . $stmt->error;
        ?>
        <meta http-equiv="refresh" content="5; url=http://localhost/dpy/db/mainPage.html"/>
        <?php
    }
} else {
    echo "No record found...";
    ?>
    <meta http-equiv="refresh" content="2; url=http://localhost/dpy/db/mainPage.html"/>
    <?php
}

// Optionally, you can close the connection
$conn->close();
?>
