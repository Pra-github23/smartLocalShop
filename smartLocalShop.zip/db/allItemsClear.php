<?php
include "connect.php";

// Check if email and id are set in the URL
if (isset($_GET['email']) && isset($_GET['id'])) {

    $userEmail = $_GET['email'];
    $id        = $_GET['id'];

    // SQL query to delete all items from the cart for the specific user
    $sql = "DELETE FROM `cart` WHERE `userEmail` = '$userEmail'";

    if ($conn->query($sql) === TRUE) {
        // If deletion is successful, redirect back to the cart page or the shop page
        header("Location: displayAll.php?id=" . urlencode($id) . "&email=" . urlencode($userEmail));
        exit;
    } else {
        // If there is an error, show an error message
        echo "Error: " . $conn->error;
    }

} else {
    // If email or id is missing, show an error message
    echo "ERROR: Missing parameters.";
}

// Close the connection
$conn->close();
?>
