<?php
include "connect.php";
 



if (isset($_POST['register'])) {
    // Sanitize and validate inputs
    $fName = $_POST['firstName'];
    $lName = $_POST['lastName'];
    $email = $_POST['email'];
    $gender = $_POST['gender'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $c_password = password_hash($_POST['confirm_password'], PASSWORD_DEFAULT);
    $mobile = $_POST['mobile'];
    $address = $_POST['address'];
    
    $tableName = "user";

    if (isset($_POST['admin'])) {
       
         
        ?>
        <meta http-equiv="refresh" content="0; url=http://localhost/dpy/db/payment.html" />
       <?php
      
    }
    //rewards table
    $rewardsConn = $conn->prepare("INSERT INTO `rewards` (email, reward_points) VALUES (?, ?)");

    // Prepare the SQL statement
    $stmt = $conn->prepare("INSERT INTO $tableName (firstname, lastname, email, gender, password,c_password, mobile, address) VALUES (?, ?, ?, ?, ?,?, ?, ?)");

    // Check if preparation was successful
    if ($stmt === false || $rewardsConn === false) {
        die("Error preparing statement: " . $conn->error);
    }

    // Bind parameters
    $rewardsConn->bind_param("si", $email, 0);
    $stmt->bind_param("ssssssss", $fName, $lName, $email, $gender, $password,$c_password, $mobile, $address);

    // Execute the statement
    if ($stmt->execute() && $rewardsConn->execute()) {
        // Redirect to main page after successful registration
        header('Location: http://localhost/dpy/db/mainPage.html');
        exit();
    } else {
        echo "ERROR: " . $stmt->error;
        ?>
        <meta http-equiv="refresh" content="5; url=http://localhost/dpy/db/mainPage.html"/>
       <?php
    }

    // Close the statement
    $stmt->close();
} else {
    echo "Error: Registration failed.";
    ?>
    <meta http-equiv="refresh" content="5; url=http://localhost/dpy/db/mainPage.html"/>
   <?php
}
?>
