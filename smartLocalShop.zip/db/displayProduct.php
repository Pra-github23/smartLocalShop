<?php
include "connect.php";

// Check if the 'email' and 'id' parameters are set
if (isset($_GET['email'])) {
    $email = mysqli_real_escape_string($conn, $_GET['email']);
    $id = $_GET['id'];

    // Check if the table for the user already exists
    $checkTableQuery = "SHOW TABLES LIKE '$email'";
    $tableExists = $conn->query($checkTableQuery);

    if ($tableExists->num_rows > 0) {
        // Table exists, retrieve product quantities
        $querySelect = "SELECT * FROM `$email` WHERE email='$email'";
        $productResults = $conn->query($querySelect);

        if ($productResults) {
            $productData = $productResults->fetch_assoc();
        } else {
            echo "Error retrieving product data: " . $conn->error;
            exit();
        }
    } else {
        // Create the table if it doesn't exist
        $createTableQuery = "CREATE TABLE `$email` (
            email VARCHAR(40) PRIMARY KEY,
            santoor INT DEFAULT 0,
            mysorsandal INT DEFAULT 0,
            closeup INT DEFAULT 0,
            dabur INT DEFAULT 0,
            lays INT DEFAULT 0,
            doritos INT DEFAULT 0,
            dark INT DEFAULT 0,
            tiger INT DEFAULT 0,
            naturali INT DEFAULT 0,
            loreal INT DEFAULT 0
        )";

        if ($conn->query($createTableQuery) === TRUE) {
            // Insert the email into the table after creation
            $insertEmailQuery = "INSERT INTO `$email` (email) VALUES ('$email')";
            $conn->query($insertEmailQuery);
            $productData = array_fill_keys(['santoor', 'mysorsandal', 'closeup', 'dabur', 'lays', 'doritos', 'dark', 'tiger', 'naturali', 'loreal'], 0);
        } else {
            echo "Error creating table: " . $conn->error;
            header("Refresh:4; url=http://localhost/dpy/db/displayAdmin.php?id=" . urlencode($id));
            exit();
        }
    }
} else {
    echo "Product data not found.";
    header("Refresh:4; url=http://localhost/dpy/db/displayAdmin.php?id=" . urlencode($id));
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="product.css" type="text/css">
    <title>Product</title>
</head>
<body>
    <form action="product.php" method="POST">
        <div class="container">
            <h1>Products</h1>
            <input type="hidden" name="email" value="<?php echo htmlspecialchars($email); ?>">
            <input type="hidden" name="id" value="<?php echo htmlspecialchars($id); ?>">

            <?php
            // List of product names
            $products = ['santoor', 'mysorsandal', 'closeup', 'dabur', 'lays', 'doritos', 'dark', 'tiger', 'naturali', 'loreal'];
                   

     
            // Loop through products and display each
            foreach ($products as $product) {
                $productName = ucfirst($product);
                $quantity = isset($productData[$product]) ? htmlspecialchars($productData[$product]) : 0;
                echo "
                <div class='product'>
                    <img src='{$product}.jpg' alt='{$productName}'>
                    <label for='{$product}'>{$productName}:</label>
                    <div class='quantity-controls'>
                        <button type='button' onclick=\"updateQuantity('{$product}', 'decrement')\">Remove</button>
                        <input type='number' id='increment-{$product}' value='1' min='1'>
                        <button type='button' onclick=\"updateQuantity('{$product}', 'increment')\">Add</button>
                        <input type='number' name='{$product}' value='{$quantity}' id='{$product}' readonly min='0' max='10000'>
                    </div>
                </div>";
            }
            ?>

            <div class="btn">
                <div class="submit">
                    <input type="submit" name="submit" value="Submit">
                </div>
                <div class="back">
                    <input type="submit" name="back" value="Back">
                </div>
            </div>
        </div>
    </form>

    <script>
        // Function to update the quantity of a product
        function updateQuantity(id, action) {
            const inputField = document.getElementById(id);
            const incrementField = document.getElementById(`increment-${id}`);
            let currentValue = parseInt(inputField.value);
            const incrementValue = parseInt(incrementField.value);

            if (action === 'increment') {
                currentValue += incrementValue;
            } else if (action === 'decrement') {
                currentValue -= incrementValue;
            }

            // Ensure the quantity stays within the limits of 0 to 10000
            currentValue = Math.max(0, Math.min(currentValue, 10000));

            inputField.value = currentValue;
        }
    </script>
</body>
</html>
