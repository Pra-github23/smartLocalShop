

<?php
include "connect.php";

if (isset($_POST['submit'])) {
    if (isset($_POST['email'])) {
        $email = mysqli_real_escape_string($conn, $_POST['email']);
        $id=$_POST['id'];
      
        // Update product quantities
        $products = ['santoor', 'mysorsandal', 'closeup', 'dabur', 'lays', 'doritos', 'dark', 'tiger', 'naturali', 'loreal'];
        foreach ($products as $product) {
            if (isset($_POST[$product])) {
               
                $newQuantity = (int)$_POST[$product];
                $updateQuery = "UPDATE `$email` SET $product = $newQuantity WHERE email = '$email'";
                $conn->query($updateQuery);
               
            }
        }
        echo "succeessfully updated...";
        // Redirect to avoid resubmission
        header("Refresh:3; http://localhost/dpy/db/displayAdmin.php?id=" . urlencode($id));
        exit();
    }
}
else if(isset($_POST['back'])){
    $id=$_POST['id'];
    header("Location: http://localhost/dpy/db/displayAdmin.php?id=" . urlencode($id));
    exit();

} else {
    echo "Invalid request method.";
    exit();
}
