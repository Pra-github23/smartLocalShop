<?php
include "connect.php";

// Check if form was submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Collect POST data
    $userEmail   = $_POST['userEmail'];
    $shopName    = $_POST['shopName'];
    $amount      = $_POST['amount'];
    $id          = $_POST['id']; // Assuming you still want to use this in the header or redirection
    $pick_later  = isset($_POST['pick_later']) ? $_POST['pick_later'] : "picking";
    $useRewards = isset($_POST['useRewards']) ? true : false;
    
    
    $sql = "SELECT `reward_points` FROM `rewards` WHERE `email` = '$userEmail'";
    $result = $conn->query($sql);
    $user = $result->fetch_assoc();

    $totalPoints = isset($user['reward_points']) ? $user['reward_points'] : 0;     //retrieve total points
    
      // Calculate how many reward points to use
    $maxPoints = floor($amount / 50); // 1 point for every 50 rupees

    if ($useRewards) {
      
        $discountAmount =$totalPoints/10;  // 10 points = 1 rupee

        // Reduce the amount by the discount
        if($discountAmount <= $amount){    //discount  less than or equals amount
           $amount = $amount - $discountAmount;
           $maxPoints = $maxPoints+($totalPoints%10);

        }
        else{                           //amount less than discount
            $discountAmount -= $amount;
            $amount = 0;
            $maxPoints += ($discountAmount * 10);
        }
     
    }

     if(!$useRewards){
        $maxPoints += $totalPoints;  //not use reward points
     }
    // Update the user's reward points in the database 
    $updateSql = "UPDATE `rewards` SET `reward_points` = $maxPoints WHERE `email` = '$userEmail'";
    $conn->query($updateSql);

    // Sanitize input to prevent SQL injection
    $userEmail = $conn->real_escape_string($userEmail);
    $shopName = $conn->real_escape_string($shopName);
    $amount = $conn->real_escape_string($amount);

    // Insert payment data into the database
    $sql = "INSERT INTO `payment` (`userEmail`, `shop_name`, `amount`, `status`) 
            VALUES ('$userEmail', '$shopName', '$amount', '$pick_later')";
    
    ?>
 
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
        <link rel="stylesheet" href="checkout.css" type="text/css">
    </head>
    <body>
    

    <?php
    if ($conn->query($sql) === TRUE) {
        // Payment successfully processed
        echo "<div class='payment-confirmation'>";
        echo "<h1>Payment Successful!</h1>";
        echo "<p><strong>User Email:</strong> " . htmlspecialchars($userEmail) . "</p>";
        echo "<p><strong>Shop Name:</strong> " . htmlspecialchars($shopName) . "</p>";
        echo "<p><strong>Total Amount Paid:</strong> ₹" . htmlspecialchars($amount) . "</p>";
        echo "<p><strong>Status:</strong> " . htmlspecialchars($pick_later) . "</p>";

        // Redirect back after 5 seconds

        echo "
              <form action='cart_view.php' method='GET'>
                            <input type='hidden' name='email' value='$userEmail'>
                           
                            <input type='hidden' name='id' value='$id'>
                           
                            <button type='submit' class='back-btn'>Back</button>
                        </form>
           ";
       
        echo "</div>";
    } else {
        // Error in payment processing
        echo "<div class='payment-error'>";
        echo "<h1>Oops!</h1>";
        echo "<p>Error processing payment: " . $conn->error . "</p>";
        echo "</div>";
    }
    ?>
     </body>
     </html>
    <?php

} else {
    echo "<p>Invalid request. Please try again.</p>";
}

$conn->close();
?>

