<?php
include "connect.php";

if(isset($_GET['id'])){
    $id=$_GET['id'];
    $table="user";
    // Execute the query
    $query = "SELECT * FROM $table where id=$id";
    $results = $conn->query($query);

    

// Check if the query was successful and if there are rows returned
     if ($results && $results->num_rows > 0) {
        
            ?>     

                <!DOCTYPE html>
                <html lang="en">
                <head>
                    <meta charset="UTF-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                    <link rel="stylesheet" href="displayAll.css" type="text/css">
                    <link rel="stylesheet" href="logout.css" type="text/css">
                    <title>displayPage</title>
                </head>
                <body>
                <form action="logout.php" method="POST">
                   <button type="submit" class="logout-btn">Logout</button>
                </form>

                <div class="totaltable">
                    <h1>CUSTOMERS DETAILS</h1>
                           <div class="points">
                              <p>10 points = 1₹</p>
                           </div>
                            <table border=1 class="table">
                                <div class="row">
                                    <tr>  
                                                <!-- <th>SNO</th> -->
                                                <th>FIRST NAME</th>
                                                <th>LAST NAME</th>
                                                <th>EMAIL</th>
                                                <th>GENDER</th>
                                                <th>MOBILE</th>
                                                <th>ADDRESS</th> 
                                                <th>Points</th>
                                                <th colspan=2>OPERATION</th>
                                            
                                    </tr><br><br>
                                
                            <?php 
                            //connect to rewards  table for displaying
                           $rewardsQuery = "SELECT reward_points FROM `rewards` WHERE email = ?";
                           $rewardConn = $conn->prepare($rewardsQuery);

                           $userEmail='';
                            while($row=$results->fetch_assoc()){
                                $userEmail=$row['email'];

                                $rewardConn->bind_param("s", $userEmail);  //bind param
                                $rewardConn->execute();                    //execute
                                $rewardResult = $rewardConn->get_result();
                                $rewardData   = $rewardResult->fetch_assoc();
                                $rewardsPoints =$rewardData['reward_points'];  //points
                                ?>
                                    
                                        <tr>
                                        <!-- <td> <?php echo $row['id'];            ?></td> -->
                                        <td> <?php echo $row['firstname']; ?></td>
                                        <td> <?php echo $row['lastname'];  ?></td>
                                        <td> <?php echo $row['email'];     ?></td>
                                        <td> <?php echo $row['gender'];    ?></td>
                                        <td> <?php echo $row['mobile'];    ?></td>
                                        <td> <?php echo $row['address'];   ?></td>
                                        <td> <?php echo $rewardsPoints     ?></td>
                                        <td class="edit">
                                            <a href="update.php?id=<?php echo urlencode($row['id']);  ?> &table=<?php echo urlencode($table); ?>" class="edit-link" style="text-decoration:none;">
                                            Edit
                                            </a> 
                                        </td>

                                        <td class="delete" >
                                            <a href="delete.php?id=<?php echo urlencode($row['id']); ?> &table=<?php echo urlencode($table); ?>" class="delete-link" style="text-decoration:none;">
                                            Del
                                            </a></td>
                                        </tr>
                                        <br>
                                </div>
                                <?php
                            } // loop end
                            ?>

                        </table>
                        <div class="product">
                         <div class="viewAllShop">
                         <a href="displayAllShop.php?id=<?php echo urlencode($id); ?>&email=<?php echo urlencode($userEmail); ?>">NearByShop</a>
                       
                         </div>

                         <div class="viewItems">
                         <a href="cart_view.php?email=<?php echo urlencode($userEmail); ?>&id=<?php echo urlencode($id); ?>">list Items</a>
                         </div>
                        </div>
                       
                </div>
                
                        </body>
                </html>

    <?php
                
 } else {
    echo "ERROR".$results->error;
    ?>
    <meta http-equiv="refresh" content="5; url=http://localhost/dpy/db/mainPage.html"/>
   <?php
}
}else{
    echo "no record found..";
    ?>
    <meta http-equiv="refresh" content="5; url=http://localhost/dpy/db/mainPage.html"/>
   <?php
}

// Optionally, you can close the connection
$conn->close();
?>
