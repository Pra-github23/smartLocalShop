<?php
include "connect.php";

// Check if email and id are set in the URL
if (isset($_GET['email']) && isset($_GET['id'])) {

    // Get the logged-in user's email and ID
    $userEmail = $_GET['email'];
    $id        = $_GET['id'];

    // SQL query to fetch cart items for the logged-in user
    $sql = "SELECT * FROM `cart` WHERE `userEmail` = '$userEmail'";
    $result = $conn->query($sql);
    
    // Array to hold cart items grouped by shop name
    $cartItemsByShop = [];

    // Group the cart items by shop name
    while ($row = $result->fetch_assoc()) {
        $cartItemsByShop[$row['shop_name']][] = $row;
    }

    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="cart_view.css" type="text/css">
        <title>Your Cart</title>
    </head>
    <body>

        <h1>Your Cart</h1>

        <div class="component">
            <div class="back">
                <a href="displayAll.php?id=<?php echo urlencode($id); ?>&email=<?php echo urlencode($userEmail); ?>" class="go-to-file-link">Back</a>
            </div>
            
            <div class="clear">
                <a href="allItemsClear.php?id=<?php echo urlencode($id); ?>&email=<?php echo urlencode($userEmail); ?>" class="go-to-file-link">Clear</a>
            </div>
        </div>

        <?php
        // Check if there are any items in the cart
        if (count($cartItemsByShop) > 0) {
            
            // Loop through each shop's cart items and display them
            foreach ($cartItemsByShop as $shopName => $items) {
                echo "<h2>$shopName</h2>"; // Display shop name
                
                // Initialize shop total
                $shopTotal = 0;

                // Start the table for each shop
                echo "<form method='POST' action='deleteItem.php'>"; // Start a form for item removal

                // Display table with header only once per shop
                echo "<table class='cart-table'>
                        <thead>
                            <tr>
                                <th>Product Image</th>
                                <th>Product Name</th>
                                <th>Quantity</th>
                                <th>Price</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>";
                
                // Display items for the current shop
                foreach ($items as $row) {
                    $shopTotal += $row['price'];

                    // Form for removing each individual item
                    echo "<form method='POST' action='deleteItem.php'>"; // Separate form for each item
                    echo "<input type='hidden' name='email' value='$userEmail'>";
                    echo "<input type='hidden' name='id' value='$id'>";
                    echo "<input type='hidden' name='product' value='" . urlencode($row['productName']) . "'>";
                    echo "<input type='hidden' name='shop_name' value='" . urlencode($row['shop_name']) . "'>";
                 

                    // Table row for each product
                    echo "<tr>";
                    echo "<td><img src='" . htmlspecialchars($row['image'] . '.jpg') . "' alt='Product Image' class='product-image' width='100'></td>";
                    echo "<td>" . htmlspecialchars($row['productName']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['quantity']) . "</td>";
                    echo "<td>₹" . htmlspecialchars($row['price']) . "</td>";
                    echo "<td><button type='submit' name='remove' value='remove' class='remove-btn'>Remove</button></td>"; // Button to remove item
                    echo "</tr>";
                    echo "</form>"; // Close the individual product form
                }
                
                echo "</tbody></table>"; // Close the table
                echo "</form>"; // Close the main form for the shop

                // Display the total for the current shop and Buy button
                echo "<div class='shop-total'>
                        <span >Total Amount: ₹" . htmlspecialchars($shopTotal) . "</span>
                         <!-- Form for Buy Now button -->
                        <form action='checkout.php' method='POST'>
                        <!-- Pick Later checkbox -->
                            <div class='pick-later-container'>
                             <input type='checkbox' name='pick_later' value='Pick Later' class='pick-later-checkbox'> 
                             <label>Pick Later</label>

                             <input type='hidden' name='userEmail' value='$userEmail'>
                             <input type='hidden' name='shopName' value='$shopName'>
                             <input type='hidden' name='amount' value='$shopTotal'>
                             <input type='hidden' name='id' value='$id'>

                              <!-- Reward Checkbox -->
                            
                             <input type='checkbox' name='useRewards' id='useRewards'>
                             <label for='useRewards'>Use Rewards</label>
                             <input type='hidden' name='rewardAmount' value='1' id='rewardAmount'>

                             <button type='submit' class='buy-btn'>Buy</button>
                           </div>
                        </form>
                      </div>";

            }

        } else {
            // If no items found, display a message
            echo "<p>Your cart is empty. Redirecting to the shop...</p>";

            // Using meta refresh tag for redirection
            ?>
            <meta http-equiv="refresh" content="4; url=http://localhost/dpy/db/displayAll.php?id=<?php echo urlencode($id); ?>&email=<?php echo urlencode($userEmail); ?>" />
            <?php
        }
        ?>

    </body>
    </html>

    <?php
} else {
    // If email or id are missing, show an error message and redirect
    echo "ERROR.. Try Again ";
    ?>
    <meta http-equiv="refresh" content="4; url=http://localhost/dpy/db/displayAll.php?id=<?php echo urlencode($id); ?>&email=<?php echo urlencode($userEmail); ?>" />
    <?php
}

// Close the connection
$conn->close();
?>
