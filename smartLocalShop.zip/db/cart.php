<?php
include "connect.php";  // Include the database connection

if (isset($_GET['action']) && $_GET['action'] == 'add') {
    // Retrieve the product details passed through the URL
    $shopEmail    = $_GET['id'];
    $productName  = $_GET['productName'];
    $quantity     = $_GET['quantity'];
    $productImage = $_GET['image'];
    $shopName     = $_GET['shop_name'];
    $userEmail    = $_GET['userEmail'];
    $userId       = $_GET['userid'];

    // Check if the product exists in the cart for the user
    $checkProduct = "SELECT quantity FROM `cart` WHERE userEmail = ? AND productName = ? AND shopEmail = ?";

    // Prepare and execute the query
    if ($stmt = $conn->prepare($checkProduct)) {
        $stmt->bind_param("sss", $userEmail, $productName, $shopEmail); // Bind the parameters
        $stmt->execute();
        $result = $stmt->get_result(); // Get the result from the query

        // Get the price for the product from the prices table
        $sql = "SELECT product_value FROM `prices` WHERE product_name='$productName'";  // This gives information about the columns in the table
            
       
         $connect = $conn->query($sql);
         
         $row = $connect->fetch_assoc();
 
         $prices = $row['product_value'];  //storing column VALUE
      
       

        // Check if the product exists in the cart
        if ($result->num_rows > 0) {
            // Product exists, fetch the current quantity
            $row = $result->fetch_assoc();
            $oldQuantity = $row['quantity'];

            // Calculate the new quantity and total amount
            $newQuantity = $oldQuantity + $quantity;
            $totalAmount = $prices * $newQuantity;

            // Update the product quantity and total amount in the cart
            $updateQuery = "UPDATE `cart` SET quantity = ?, price = ? WHERE userEmail = ? AND productName = ? AND shopEmail = ?";

            // Prepare and execute the update query
            if ($updateStmt = $conn->prepare($updateQuery)) {
                $updateStmt->bind_param("idsss", $newQuantity, $totalAmount, $userEmail, $productName, $shopEmail);
                if ($updateStmt->execute()) {
                    echo "Product quantity updated in the cart.";
                    header('Location: view_Products.php?table=' . urlencode($shopEmail) . '&userEmail=' . urlencode($userEmail) . '&id=' . urlencode($userId));
                    exit;
                } else {
                    echo "Error updating product in cart: " . $conn->error;
                }
            } else {
                echo "Error preparing update statement: " . $conn->error;
            }
        } else {
            // Product does not exist in the cart, insert the new product into the cart
            $insertQuery = "INSERT INTO `cart` (userEmail, productName, quantity, image, shop_name, shopEmail, price) 
                            VALUES (?, ?, ?, ?, ?, ?, ?)";

            // Prepare and execute the insert query
            if ($insertStmt = $conn->prepare($insertQuery)) {
                $totalAmount = $prices * $quantity;
                $insertStmt->bind_param("ssisssd", $userEmail, $productName, $quantity, $productImage, $shopName, $shopEmail, $totalAmount);
                if ($insertStmt->execute()) {
                    echo "Product added to cart successfully.";
                    header('Location: view_Products.php?table=' . urlencode($shopEmail) . '&userEmail=' . urlencode($userEmail) . '&id=' . urlencode($userId));
                    exit;
                } else {
                    echo "Error inserting product into cart: " . $conn->error;
                }
            } else {
                echo "Error preparing insert statement: " . $conn->error;
            }
        }
        $stmt->close();
    } else {
        echo "Error preparing check query: " . $conn->error;
    }
} else {
    echo "Invalid action.";
}

// Close the connection
$conn->close();
?>
