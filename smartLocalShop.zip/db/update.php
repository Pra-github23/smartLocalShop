


<?php
include "connect.php";

// Validate and sanitize the incoming ID
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $id = intval($_GET['id']); // Convert to integer for safety
    $table=$_GET['table'];
    // Fetch user data to populate the form
    
    $query = "SELECT firstname, lastname, email, gender, mobile, address FROM $table WHERE id = ?";
    $stmt = $conn->prepare($query);
    if($stmt===false){
        die("stmt error..");
    }
    $stmt->bind_param("i", $id); // Bind the ID as an integer
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc(); // Fetch the user data
    } else {
        die("No user found with that ID.");
    }
    $stmt->close();
} else {
    die("Invalid ID.");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css" type="text/css">
    <title>Update form</title>
   
</head>
<body >
   
    <form action="updateDetails.php" method="POST">
        <div class="container">
            <h1 class="heading">Update form</h1>
            <input type="hidden" name="id" value="<?php echo $id; ?>">
            <input type="hidden" name="table" value="<?php echo $table; ?>">
            <div class="input">
                <label for="">FIRST NAME</label>
                <input type="text" placeholder="first name" name="firstName" value="<?php echo htmlspecialchars($user['firstname']); ?>">
            </div>
            <div class="input">
                <label for="">LAST NAME</label>
                <input type="text" placeholder="last name" name="lastName" value="<?php echo htmlspecialchars($user['lastname']); ?>">
            </div>
            <div class="input">
                <label for="">EMAIL</label>
                <input type="email" placeholder="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>">
            </div>
            <div class="input">
                <label for="">GENDER</label>
                <select class="select" name="gender">
                    <option value="not_select">select</option>
                    <option value="male" <?php if ($user['gender'] == 'male') echo "selected"; ?>>Male</option>
                    <option value="female" <?php if ($user['gender'] == 'female') echo "selected"; ?>>Female</option>
                    <option value="other" <?php if ($user['gender'] == 'other') echo "selected"; ?>>Other</option>
                </select>
            </div>
            
            <div class="input">
                <label for="">MOBILE</label>
                <input type="number" placeholder="mobile" name="mobile" value="<?php echo htmlspecialchars($user['mobile']); ?>">
            </div>
            <div class="input">
                <label for="">ADDRESS</label>
                <textarea placeholder="address" class="textarea" name="address"><?php echo htmlspecialchars($user['address']); ?></textarea>
            </div>
            <div class="check-box">
                <div class="checkit">
                <input type="checkbox"  required>
                <p class="para"><em>Agree to terms and conditions</em></p>
                </div>
            </div>
            <div class="btn">
                <input type="submit" value="Update" name="update" class="btn-inside">
            </div>
        </div>
    </form>

    
</body>
</html>
