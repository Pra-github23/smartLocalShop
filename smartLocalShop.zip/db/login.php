<?php
include "connect.php";

if (isset($_POST['sign'])) {
    $option = $_POST['select'];
    $email = $_POST['email'];
    $passwordOriginal = $_POST['password'];

    
        
        $query = "SELECT * FROM $option WHERE email=?";
        $stmt = $conn->prepare($query);
        if ($stmt === false) {
            ?>
            <meta http-equiv="refresh" content="4; url=http://localhost/dpy/db/mainPage.html"/>
            <?php
            die("Statement preparation failed: select  correct option");
           

        }
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $passwordHashDB = $row['password'];
            $emailDB = $row['email'];
            

            if (password_verify($passwordOriginal, $passwordHashDB) && $email === $emailDB) {
                $id = $row['id'];
                $redirectUrl = ($option === "admin") ? "displayAdmin.php" : "displayAll.php";
                header("Location: http://localhost/dpy/db/$redirectUrl?id=$id");
                exit();
            } else {
                
                echo "Invalid email or password";
                ?>
                <meta http-equiv="refresh" content="4; url=http://localhost/dpy/db/mainPage.html"/>
               <?php
            }
            $stmt->close();
        } else {
            echo "not existed..";
            ?>
            <meta http-equiv="refresh" content="3; url=http://localhost/dpy/db/mainPage.html"/>
           <?php
        }
       
    }  else {
    echo "Not signed in.";
}
?>
