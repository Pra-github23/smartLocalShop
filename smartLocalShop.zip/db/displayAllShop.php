<?php
include "connect.php";
$sql = "SELECT table_name FROM information_schema.tables WHERE table_schema = 'mrpy' AND table_name LIKE '%@gmail.com'";
$id = isset($_GET['id']) ? $_GET['id'] : -1;
$userEmail = isset($_GET['email']) ? $_GET['email'] : '';


$result = $conn->query($sql);
$tableNames = array();
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $tableNames[] = $row['TABLE_NAME'];
    }
} else {
    echo "<p>No tables found in the database.</p>";
}
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Table Names</title>
    <link rel="stylesheet" href="displayAllShop.css" type="text/css">
</head>
<body>
    <h1>Shop Names</h1>
      <a href="displayAll.php?id=<?php echo urlencode($id); ?>" class="go-to-file-link">
         
         <button class="go-to-file-button">Back</button>
      </a>
    <div class="table-container">
        <?php foreach ($tableNames as $tableName) {
            $Name = str_replace('@gmail.com', '', $tableName);
            echo "<div class='table-card'>
                    <h3>" . htmlspecialchars($Name) . "</h3>
                    <a href='view_Products.php?table=" . urlencode($tableName) . "&id=" . urlencode($id) . "&userEmail=" . urlencode($userEmail) . "' class='view-btn'>View Products</a>
                  </div>";
        } ?>
    </div>
</body>
</html>
