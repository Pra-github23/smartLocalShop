<?php
include "connect.php";

// Check if the email and id are set in the URL
if (isset($_GET['id']) && isset($_GET['email'])) {
    $id = $_GET['id'];
    $email = $_GET['email'];
    $shopName = str_replace('@gmail.com', '', $email); // Remove @gmail.com from email

    // SQL query to get payment status for a particular shop
    $sql = "SELECT userEmail, amount, status FROM `payment` WHERE shop_name = '$shopName'";

    if ($results = $conn->query($sql)) {
        // Check if any rows are returned
        if ($results->num_rows > 0) {
            // Segregate the orders by their status
            $pickingOrders = [];
            $pickedOrders = [];
            $pickLaterOrders = [];

            while ($row = $results->fetch_assoc()) {
                $userEmail = $row['userEmail'];
                $amount = $row['amount'];
                $status = $row['status'];

                // Categorize orders based on status
                if ($status == 'picking') {
                    $pickingOrders[] = $row;
                } elseif ($status == 'picked') {
                    $pickedOrders[] = $row;
                } elseif ($status == 'Pick Later') {
                    $pickLaterOrders[] = $row;
                }
            }

            // Displaying the orders segregated by status
            ?>
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Order Status for Shop: <?php echo htmlspecialchars($shopName); ?></title>
                <link rel="stylesheet" href="pickStatus.css" type="text/css">
                <script>
                    function showSection(section) {
                        var sections = document.querySelectorAll('.status-section');
                        sections.forEach(function(sec) {
                            sec.style.display = 'none';
                        });
                        document.getElementById(section).style.display = 'block';
                    }
                </script>
            </head>
            <body>
                <div class="container">
                    <h1>Order Status for Shop: <?php echo htmlspecialchars($shopName); ?></h1>

                    <!-- Back Button -->
                    <div style="margin-bottom: 20px; text-align: center;">
                        <a href="displayAdmin.php?id=<?php echo urlencode($id); ?>" class="back-button">Back</a>
                    </div>

                    <!-- Buttons to Switch between Sections -->
                    <div class="tabs">
                        <button onclick="showSection('pickingSection')">Picking Orders</button>
                        <button onclick="showSection('pickedSection')">Picked Orders</button>
                        <button onclick="showSection('pickLaterSection')">Pick Later Orders</button>
                    </div>

                    <!-- Wrapper for side-by-side sections -->
                    <div class="status-wrapper">
                        <!-- Section for "Picking" Orders -->
                        <div id="pickingSection" class="status-section" style="display: block;">
                            <h2>Picking Orders</h2>
                            
                                <div class="table-wrapper">
                                    <table>
                                        <thead>
                                            <tr>
                                                <th>User Email</th>
                                                <th>Amount</th>
                                                <th>Status</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php
                                        foreach ($pickingOrders as $row) {
                                            
                                            echo "<form action='pickUpdate.php' method='POST'>";
                                            echo "<tr>";
                                            echo "<td>" . htmlspecialchars($row['userEmail']) . "</td>";
                                            echo "<td>" . htmlspecialchars($row['amount']) . "</td>";
                                            echo "<td>" . htmlspecialchars($row['status']) . "</td>";
                                            echo "<td>
                                                   
                                                    <input type='hidden' name='shop_name' value='" . $shopName . "'>
                                                    <input type='hidden' name='userEmail' value='" . $row['userEmail'] . "'>
                                                    <input type='hidden' name='amount' value='" . $row['amount'] . "'>
                                                    <input type='hidden' name='id' value='" . $id . "'>
                                                    <button type='submit' name='update_status' value='picked'>Mark as Picked</button>
                                                </td>";
                                            echo "</tr>";
                                            echo "</form>";
                                        }
                                        ?>
                                        </tbody>
                                    </table>
                                </div>
                            
                        </div>

                        <!-- Section for "Picked" Orders -->
                        <div id="pickedSection" class="status-section" style="display: none;">
                            <h2>Picked Orders</h2>
                            <div class="table-wrapper">
                                <table>
                                    <thead>
                                        <tr>
                                            <th>User Email</th>
                                            <th>Amount</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                    foreach ($pickedOrders as $row) {
                                        echo "<tr>";
                                        echo "<td>" . htmlspecialchars($row['userEmail']) . "</td>";
                                        echo "<td>" . htmlspecialchars($row['amount']) . "</td>";
                                        echo "<td>" . htmlspecialchars($row['status']) . "</td>";
                                        echo "</tr>";
                                    }
                                    ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <!-- Section for "Pick Later" Orders -->
                        <div id="pickLaterSection" class="status-section" style="display: none;">
                            <h2>Pick Later Orders</h2>
                           
                                <div class="table-wrapper">
                                    <table>
                                        <thead>
                                            <tr>
                                                <th>User Email</th>
                                                <th>Amount</th>
                                                <th>Status</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php
                                        foreach ($pickLaterOrders as $row) {
                                            echo " <form action='pickUpdate.php' method='POST'>";
                                            echo "<tr>";
                                            echo "<td>" . htmlspecialchars($row['userEmail']) . "</td>";
                                            echo "<td>" . htmlspecialchars($row['amount']) . "</td>";
                                            echo "<td>" . htmlspecialchars($row['status']) . "</td>";
                                            echo "<td>
                                                   
                                                    <input type='hidden' name='shop_name' value='" . $shopName . "'>
                                                    <input type='hidden' name='userEmail' value='" . $row['userEmail'] . "'>
                                                    <input type='hidden' name='amount' value='" . $row['amount'] . "'>
                                                    <input type='hidden' name='id' value='" . $id . "'>
                                                    <button type='submit' name='update_status' value='picked'>Mark as Picked</button>
                                                </td>";
                                            echo "</tr>";
                                            echo "</form>";
                                        }
                                        ?>
                                        </tbody>
                                    </table>
                                </div>
                            
                        </div>
                    </div>
                </div>
            </body>
            </html>
            <?php
        } else {
            // If no orders are found
            echo "<p class='error'>No orders found for this shop.</p>";
            ?>
            <meta http-equiv="refresh" content="3; url=http://localhost/dpy/db/displayAdmin.php?id=<?php echo urlencode($id); ?>" />
            <?php
        }
    } else {
        // Query failed
        echo "<p class='error'>Error: " . $conn->error . "</p>";
    }
} else {
    // If email or id are missing, show an error message and redirect
    echo "<p class='error'>Error: Missing ID or Email.</p>";
    ?>
    <meta http-equiv="refresh" content="3; url=http://localhost/dpy/db/displayAdmin.php?id=<?php echo urlencode($_GET['id']); ?>" />
    <?php
}

$conn->close();
?>
