<?php
include "connect.php";
 if(isset($_POST['delete'])){
    $id=$_POST['id'];
    $table=$_POST['table'];
    $query="DELETE FROM $table where id=?";
    $stmt=$conn->prepare($query);
    $stmt->bind_param("i",$id);
    if($stmt->execute()){
       if($table === "user"){
        ?>
          <meta http-equiv="refresh" content="0; url=http://localhost/dpy/db/displayAll.php?<?php echo urlencode($id); ?>"/>
        <?php
       }
       if($table === "admin"){
        ?>
          <meta http-equiv="refresh" content="0; url=http://localhost/dpy/db/displayAdmin.php?<?php echo urlencode($id); ?>"/>
        <?php
       }
    }
    else{
        echo "not deleted.";
        if($table === "user"){
          ?>
            <meta http-equiv="refresh" content="3; url=http://localhost/dpy/db/displayAll.php?<?php echo urlencode($id); ?>"/>
          <?php
         }
         if($table === "admin"){
          ?>
            <meta http-equiv="refresh" content="3; url=http://localhost/dpy/db/displayAdmin.php?<?php echo urlencode($id); ?>"/>
          <?php
         }

    }
  $stmt->close();
 }else{
    echo "try again..";
    if($table === "user"){
      ?>
        <meta http-equiv="refresh" content="3; url=http://localhost/dpy/db/displayAll.php?<?php echo urlencode($id); ?>"/>
      <?php
     }
     if($table === "admin"){
      ?>
        <meta http-equiv="refresh" content="3; url=http://localhost/dpy/db/displayAdmin.php?<?php echo urlencode($id); ?>"/>
      <?php
     }

 }
?>