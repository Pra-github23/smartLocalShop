<?php
include "connect.php";

// Check if the form data is submitted
if (isset($_POST['update_status'])) {
    
    $shopName  = $_POST['shop_name'];
    $userEmail = $_POST['userEmail'];
    $amount    = $_POST['amount'];
    $status    = $_POST['update_status'];  // 'picked'
    $id        = $_POST['id'];

    // Update the status in the database
    $sql = "UPDATE `payment` SET status = ? WHERE shop_name= ? AND amount = ? AND userEmail = ?";
    
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param('ssds', $status,$shopName, $amount, $userEmail);
        
        if ($stmt->execute()) {
            // Redirect back to the order status page with updated status
            header("Location: pickStatus.php?id=" . urlencode($id) . "&email=" . urlencode($shopName."@gmail.com"));
            exit();
        } else {
            echo "<p class='error'>Error: " . $conn->error . "</p>";
        }
        
        $stmt->close();
    } else {
        echo "<p class='error'>Error: Could not prepare the statement.</p>";
    }
}

$conn->close();
?>
