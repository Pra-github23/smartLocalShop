<?php

include "connect.php";

    if (isset($_POST['update'])) {
        $fName = $_POST['firstName'];
        $lName = $_POST['lastName'];
        $email = $_POST['email'];
        $gender = $_POST['gender'];
        $mobile = $_POST['mobile'];
        $address = $_POST['address'];
        $id = $_POST['id'];
        $table=$_POST['table'];

        $query = "UPDATE $table SET firstname=?, lastname=?, email=?, gender=?, password=?, mobile=?, address=? WHERE id=?";
        
        $stmt = $conn->prepare($query);
        if ($stmt === false) {
            if($table === "user"){
            
                ?>
                 <meta http-equiv="refresh" content="5; url=http://localhost/dpy/db/displayAll.php?id=<?php echo urlencode($id); ?>" />
                <?php
               }
               if($table === "admin"){
               
                ?>
                <meta http-equiv="refresh" content="5; url=http://localhost/dpy/db/displayAdmin.php?id=<?php echo urlencode($id); ?>" />
               <?php
               }
           
            die("Statement preparation failed: try again..." );
        }
        $stmt->bind_param("sssssssi", $fName, $lName, $email, $gender, $password, $mobile, $address, $id);

        if ($stmt->execute()) {
          
           if($table === "user"){
            
            ?>
             <meta http-equiv="refresh" content="0; url=http://localhost/dpy/db/displayAll.php?id=<?php echo urlencode($id); ?>" />
            <?php
           }
           if($table === "admin"){
           
            ?>
            <meta http-equiv="refresh" content="0; url=http://localhost/dpy/db/displayAdmin.php?id=<?php echo urlencode($id); ?>" />
           <?php
           }
         
        } else {
            echo "ERROR: not updated  please enter unique.. or server busy..." ;
            if($table === "user"){
            
                ?>
                 <meta http-equiv="refresh" content="5; url=http://localhost/dpy/db/displayAll.php?id=<?php echo urlencode($id); ?>" />
                <?php
               }
               if($table === "admin"){
               
                ?>
                <meta http-equiv="refresh" content="5; url=http://localhost/dpy/db/displayAdmin.php?id=<?php echo urlencode($id); ?>" />
               <?php
               }
           
        }

        $stmt->close();
    } 
    else {
        echo "Not updated...";
        if($table === "user"){
            
            ?>
             <meta http-equiv="refresh" content="2; url=http://localhost/dpy/db/displayAll.php?id=<?php echo urlencode($id); ?>" />
            <?php
           }
           if($table === "admin"){
           
            ?>
            <meta http-equiv="refresh" content="2; url=http://localhost/dpy/db/displayAdmin.php?id=<?php echo urlencode($id); ?>" />
           <?php
           }
    }
    ?>
