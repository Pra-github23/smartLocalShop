<?php
include "connect.php";  // Include the database connection

// Get the table name from the URL parameter
$tableName = isset($_GET['table']) ? $_GET['table'] : '';
$Name = str_replace('@gmail.com', '', $tableName); // Remove @gmail.com from table name

$id=isset($_GET['id']) ? $_GET['id'] : -1;
$userEmail=isset($_GET['userEmail']) ? $_GET['userEmail'] : '';

// Validate table name (use only alphanumeric characters and underscores to prevent SQL injection)
if ($tableName === '') {
    die("Invalid table name.");
}

// SQL query to fetch all columns for the specified table
$sql = "DESCRIBE `$tableName`";  // This gives information about the columns in the table
$result = $conn->query($sql);

// Check if the table exists and retrieve the columns
if ($result->num_rows > 0) {
    // Store column names
    $columns = array();
    while ($row = $result->fetch_assoc()) {
        if ($row['Field'] !== 'email')  // Skip the 'email' column
            $columns[] = $row['Field'];  //storing column name
    }

    // SQL query to fetch all data from the table
    $sqlData = "SELECT * FROM `$tableName`";
    $dataResult = $conn->query($sqlData);

   

    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="view_Products.css" type="text/css">
        <title>View Products</title>
    </head>
    <body>
        <h1 class="shop-name">Shop Name: <?php echo htmlspecialchars($Name); ?></h1>

        <a href="displayAllShop.php?id=<?php echo urlencode($id); ?>&email=<?php echo urlencode($userEmail); ?>" class="go-to-file-link">
         
            <button class="go-to-file-button">Back</button>
         </a>


        <div class="products-grid">
        <?php
        if ($dataResult->num_rows > 0) {

           
            // Loop through each row of data and display it in the desired format
            while ($row = $dataResult->fetch_assoc()) {
                echo "<div class='product-container'>";
                
                
            
                // Display column names and values
                foreach ($columns as $column) {
                       
                            
                    $sqlPrice = "SELECT product_value FROM `prices` where product_name='$column'";  // This gives information about the columns in the table
                
               
                    $connect = $conn->query($sqlPrice);
                    $priceValue = $connect->fetch_assoc();

                        echo "<div class='product-image-container'>";
                        echo "<img src='{$column}.jpg' alt='" . htmlspecialchars($column) . "' class='product-image'>";
                        echo "</div>";
                        echo "<div class='product-column-name'>";
                        echo "<strong>" . htmlspecialchars($column) . ":" . htmlspecialchars($priceValue['product_value']) . "</strong>";
                        echo "</div>";
                        echo "<div class='product-column-value'>";
                        echo htmlspecialchars($row[$column]);
                        echo "</div>";
                   
                

                // Add to Cart section
                echo "<div class='add-to-cart-container'>";
                echo "<form method='get' action='cart.php'>
                        <input type='hidden' name='action' value='add'>
                        <input type='hidden' name='id' value='$tableName'>
                        <input type='hidden' name='userid' value='$id'>
                        <input type='hidden' name='userEmail' value='$userEmail'>
                        <input type='hidden' name='productName' value='$column'>
                        <input type='hidden' name='image' value='$column'>
                        <input type='hidden' name='shop_name' value='$Name'>
                        <label for='quantity'>Quantity:</label>
                        <input type='number' name='quantity' id='quantity' value='1' min='1'>
                        <button type='submit' class='add-to-cart'>Add to Cart</button>
                      </form>";
                echo "</div>";
                }
                echo "</div>"; // End of product-container
             }
                   
        } 

       }else {
            echo "<p class='no-data'>No data found in the table.</p>";
        }
        ?>
        </div>
    </body>
    </html>
    <?php
    // Close the connection
    $conn->close();
    ?>
