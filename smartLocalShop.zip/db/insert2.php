<?php
include "connect.php";
 
if (isset($_POST['register'])) {
    // Sanitize and validate inputs
    $fName = $_POST['firstName'];
    $lName = $_POST['lastName'];
    $email = $_POST['email'];
    $gender = $_POST['gender'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $c_password = password_hash($_POST['confirm_password'], PASSWORD_DEFAULT);
    $mobile = $_POST['mobile'];
    $address = $_POST['address'];
    
    $tableName = "admin";

    

    // Prepare the SQL statement
    $stmt = $conn->prepare("INSERT INTO $tableName (firstname, lastname, email, gender, password, c_password, mobile, address) VALUES (?, ?, ?, ?, ?, ?, ?,?)");

    // Check if preparation was successful
    if ($stmt === false) {
        
        die("Error preparing statement: " . $conn->error);
    }

    // Bind parameters
    $stmt->bind_param("ssssssss", $fName, $lName, $email, $gender, $password,$c_password, $mobile, $address);

    // Execute the statement
    if ($stmt->execute()) {
        // Redirect to main page after successful registration
        header('Location: http://localhost/dpy/db/mainPage.html');
        exit();
    } else {
      
        echo "ERROR: " . $stmt->error;
    }

    // Close the statement
    $stmt->close();
} else {
    echo "Error: Registration failed.";
}
?>
